const KAABA = Object.freeze({ lat: 21.422487, lng: 39.826206 });
function toRadians(v) {
  return (v * Math.PI) / 180;
}
function toDegrees(v) {
  return (v * 180) / Math.PI;
}
function normalizeDegree(v) {
  return ((v % 360) + 360) % 360;
}
function calculateQiblaBearing(latitude, longitude) {
  const p1 = toRadians(latitude),
    l1 = toRadians(longitude),
    p2 = toRadians(KAABA.lat),
    l2 = toRadians(KAABA.lng),
    d = l2 - l1,
    y = Math.sin(d),
    x = Math.cos(p1) * Math.tan(p2) - Math.sin(p1) * Math.cos(d);
  return normalizeDegree(toDegrees(Math.atan2(y, x)));
}
function calculateDistanceToKaaba(latitude, longitude) {
  const r = 6371.0088,
    dLat = toRadians(KAABA.lat - latitude),
    dLng = toRadians(KAABA.lng - longitude),
    a =
      Math.sin(dLat / 2) ** 2 +
      Math.cos(toRadians(latitude)) *
        Math.cos(toRadians(KAABA.lat)) *
        Math.sin(dLng / 2) ** 2;
  return r * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
function getDirectionName(degree) {
  const d = [
    "Kuzey",
    "Kuzey-Kuzeydoğu",
    "Kuzeydoğu",
    "Doğu-Kuzeydoğu",
    "Doğu",
    "Doğu-Güneydoğu",
    "Güneydoğu",
    "Güney-Güneydoğu",
    "Güney",
    "Güney-Güneybatı",
    "Güneybatı",
    "Batı-Güneybatı",
    "Batı",
    "Batı-Kuzeybatı",
    "Kuzeybatı",
    "Kuzey-Kuzeybatı",
  ];
  return d[Math.round(normalizeDegree(degree) / 22.5) % 16];
}
function angularDifference(a, b) {
  return Math.abs(((a - b + 540) % 360) - 180);
}
